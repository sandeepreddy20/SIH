package com.example.android.raghu;

public class Model {

    String title,image,description;

    public Model(){}


    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

   /* public String getLikes() {
        return likes;
    }

    public void setLikes(String description) {
        this.description = description;
    }*/

}
